Amb NodeJS instal·lat:

npm install
npm run dev

Navegar a http://localhost:3000